import os
import numpy as np
import pandas as pd
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

#ファイルパス
path1 = "../1_get_tweet/twitter_data/{}.{}.{}-{}.{}.csv"
path2 = "output/text_{}.{}.{}-{}.{}.csv"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

os.makedirs("output", exist_ok=True)

#１ファイル処理（ループ）
while True:
    ld = get_last_date(sd)

    #入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)
    out_file_path = path2.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    #ファイル（テキスト列）の読み込み
    df = pd.read_csv(get_file_path, encoding='utf-8', low_memory=False)
    df = df[["テキスト"]]
    df.index = np.arange(1, len(df) + 1)

    #ファイル出力
    df.to_csv(out_file_path)

    # 次のファイル処理（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)