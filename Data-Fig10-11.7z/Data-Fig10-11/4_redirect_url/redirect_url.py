import os, time, requests
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

# ファイルパス
path1 = "../3_get_url/output/short_url_{}.{}.{}-{}.{}.txt"
path2 = "output/url_{}.{}.{}-{}.{}.txt"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 対象外のURL
exp = ['twitter.com/', 'facebook.com/', 'htn.to/', 'kas.pr/', 'iptops.com/', 'piyolog.hatenadiary.jp/']

os.makedirs("output", exist_ok=True)

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

# リダイレクト処理関数
def get_redirect_url(url):
    url_list = []
    while True:
        res = requests.head(url, allow_redirects=False, timeout=(6.0, 10.0))
        time.sleep(10)
        if 'Location' in res.headers:
            url = res.headers['Location']
            if url in url_list:
                return url
            else:
                url_list.append(url)
        else:
            return url

# １ファイル処理（ループ）
while True:
    ld = get_last_date(sd)
    print(str(sd.year) + '/' + str(sd.month))

    # 入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)
    out_file_path = path2.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    if os.path.exists(get_file_path):

        # 入出力ファイルを開く
        read_file = open(get_file_path, 'r', encoding='utf-8')
        make_file = open(out_file_path, 'w', encoding='utf-8')

        # １行処理（ループ）
        while True:
            line = read_file.readline()
            if line:

                # 番号とURLの抽出
                idx = line.find(' ')
                num = line[: idx]
                url = line[idx + 1 : -1]
                error = 0

                # URLの展開
                try:
                    url = get_redirect_url(url)
                except requests.exceptions.RequestException:
                    error = 1
                
                if error == 0:
                    for item in exp:
                        if item in url:
                            error = 1
                
                # 出力ファイルへの書き込み
                if error == 0:
                    make_file.write(num + ' ' + url + '\n')

            # 読み込む行が存在しない為、入出力ファイルを閉じて終了
            else:         
                read_file.close()
                make_file.close()
                break
       
    # 次のファイル処理（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)