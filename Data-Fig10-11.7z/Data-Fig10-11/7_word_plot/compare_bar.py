import os, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from a2_word_plot_1 import start_date, end_date
from a3_1_word_plot_2 import compare_dict, max

# 出力先ファイルパス
path = "output/compare/bar/"

def check_prd(year, prd):
    if (year == sy) and (len(set(exist_1) & set(prd)) == 0) or (year == ey) and (len(set(exist_2) & set(prd)) == 0):
        return 1
    else:
        return 0

data = {}
sy = start_date.year
ey = end_date.year
years = np.arange(sy, ey + 1)
months = np.arange(1, 12 + 1)
per_month = (1, 2, 3, 4, 6, 12)
exist_1 = np.arange(start_date.month, 12 + 1)
exist_2 = np.arange(1, end_date.month + 1)

for group, compare in compare_dict.items():
    data[group] = {}
    for cat, cnt in compare.items():
        idx = 0
        data[group][cat] = {}
        for year in years:
            data[group][cat][year] = 0
            if year == sy:
                for _ in range(12-start_date.month+1):
                    data[group][cat][year] += cnt[idx]
                    idx += 1
            elif year == ey:
                for _ in range(end_date.month):
                    data[group][cat][year] += cnt[idx]
                    idx += 1
            else:
                for _ in range(12):
                    data[group][cat][year] += cnt[idx]
                    idx += 1
        if idx != max:
            sys.exit('Inconsistency in the number of elements')

# グラフの作成
for group, compare in compare_dict.items():
    df = pd.DataFrame({'year':years})
    df = df.set_index('year')
    for cat in compare.keys():
        items = []
        for year in years:
            items.append(data[group][cat][year])
        df[cat] = items
        os.makedirs(path, exist_ok=True)
        df.plot(kind='bar', stacked=True, figsize=(12, 8))
        plt.xticks(rotation=0, fontsize=25)
        plt.yticks(fontsize=25)
        plt.legend(fontsize=25)
        plt.xlabel('')
        plt.savefig(path + str(group) + '.pdf')
        plt.clf()
        plt.close()