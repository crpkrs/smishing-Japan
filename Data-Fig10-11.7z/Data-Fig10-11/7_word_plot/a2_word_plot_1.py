import os
from dateutil.relativedelta import relativedelta
from a1_word_count import path1, words, start_date, end_date, all_word_month_count, get_last_date

sd = start_date
words_all_month = {}
words_month = {}
x = []

# １ファイル処理（ループ）
while True:
    ld = get_last_date(sd)

    # 入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    if os.path.exists(get_file_path):

        # 入力ファイルを開く
        with open(get_file_path, 'r', encoding='utf-8') as read_file:

            # １行処理（ループ）
            while True:
                line = read_file.readline()
                line = line[: -1]
                if line:

                    # 単語のカウント
                    if line in words_month:
                        words_month[line] += 1
                    else:
                        words_month[line] = 1
                else:
                    break
    
    # X軸
    x_label = str(sd.year) + '/' + str(sd.month)
    x.append(x_label)
            
    # 総カウント数が多い順に、年月ごとのカウント数を格納する。
    for word in all_word_month_count.keys():
        
        # 指定の年月に含まれる単語には、そのカウント数を追加
        if word in words_month:
            all_word_month_count[word].append(words_month[word])
        # 指定の年月に含まれない単語には、「0」をリストに追加
        else:
            all_word_month_count[word].append(0)

        words_month[word] = 0

    # 次のファイル処理（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)