import sys
import numpy as np
from a2_word_plot_1 import x, all_word_month_count
from a3_0_patern import patern_dict, other_name

# 対象外単語の判別
def check_except(word_key):
    for w_exp in word_except:
        Find = w_exp.search(word_key)
        if Find != None:
            return 1
    return 0

# 抽出した単語を格納するリストの生成
dict_w = {}
compare_dict = {}
for group, compare in patern_dict.items():
    dict_w[group] = {}
    compare_dict[group] = {}
    for cat, paterns in compare.items():
        dict_w[group][cat] = {}
        compare_dict[group][cat] = {}

# 初期値
default = [0]*len(x)

# パターンに一致する単語数の取得
word_except = []
word_count_all_category = np.array(default)
for group, compare in patern_dict.items():
    for cat, paterns in compare.items():
        for patern in paterns:
            if type(patern) is list:
                word_except = []
                for pat in patern:
                    word_except.append(pat)
            else:
                compare_dict[group][cat] = np.array(default)
                for word_key in all_word_month_count.keys():
                    if check_except(word_key) == 0:
                        search_word = patern.search(word_key)
                        if search_word != None:
                            dict_w[group][cat][word_key] = np.array(all_word_month_count[word_key])
                            compare_dict[group][cat] += dict_w[group][cat][word_key]
                word_count_all_category += compare_dict[group][cat]
                compare_dict[group][cat] = compare_dict[group][cat].tolist()
                max = len(compare_dict[group][cat])
                word_except = []
word_count_all_category = word_count_all_category.tolist()

# その他の処理
for group, compare in compare_dict.items():
    other_cat = []
    for cat, cnt in compare.items():
        if sum(cnt) < 20:
            other_cat.append(cat)
            if sum(cnt) == 0:
                sys.exit('The cumulative number of words for \"' + cat + '\" is 0')
    compare_dict[group][other_name] = np.array(default)
    for o_cat in other_cat:
        compare_dict[group][other_name] += np.array(compare_dict[group][o_cat])
        del compare_dict[group][o_cat]