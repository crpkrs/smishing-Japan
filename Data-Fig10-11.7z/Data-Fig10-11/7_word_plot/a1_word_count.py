import os
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

# ファイルパス
path1 = "../6_get_word/output/word_{}.{}.{}-{}.{}.txt"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

words = {}
x = []

# １ファイル処理（ループ）
while True:
    ld = get_last_date(sd)

    # 入力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    if os.path.exists(get_file_path):

        # 入力ファイルを開く
        with open(get_file_path, 'r', encoding='utf-8') as read_file:

            # １行処理（ループ）
            while True:
                line = read_file.readline()
                line = line[: -1]
                if line:

                    # 単語のカウント
                    if line in words:
                        words[line] += 1
                    else:
                        words[line] = 1
                else:
                    break
       
    # 次のファイル処理（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)  

# 回数が多い順にソート
words = sorted(words.items(), key=lambda i: i[1], reverse=True)

# すべての単語の年月ごとのカウント数を格納する空のリストを作成
all_word_month_count = {}
for word in words:
    word = word[0]
    if not word in all_word_month_count.keys():
        all_word_month_count[word] = []