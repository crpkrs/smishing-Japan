import re

# その他
other_name = 'All others'

# 抽出する単語パターン
patern_dict = {

    'spoofing':{
    'Home delivery':
    [re.compile('宅配|佐川|ヤマト|UberEats|ウーバーイーツ', re.IGNORECASE)],

    'Bank':
    [re.compile('銀行|日銀|MHBK|MUFG|SMBC|JNB', re.IGNORECASE)],

    'Credit card':
    [re.compile('カード会社|JCB|Visa|Mastercard|(三井住友|エムアイ|UC|エポス|楽天|ポケット|大丸松坂屋|JFR)カード')],

    'Mobile carrier':
    [re.compile('(通信|電話)(事業者|会社)|携帯(電話)?会社|docomo|DOCOMO|ドコモ|KDDI|ソフトバンク|softbank|楽天モバイル|LINEモバイル|dアカウント', re.IGNORECASE)],

    'E-commerce':
    [re.compile('(EC|ショッピング|通販)サイト|Amazon|アマゾン|楽天市場|DMM', re.IGNORECASE)],

    'Insurance company':
    [re.compile('保険会社|朝日生命|アフラック|住友生命')],

    'Google':
    [re.compile('Google|グーグル|chrome|Play|プレイストア', re.IGNORECASE)],

    'Apple':
    [re.compile('Apple|アップル', re.IGNORECASE)],

    'Electronic payment':
    [re.compile('電子決済|LINEPay|Paidy', re.IGNORECASE)],

    'Consumer finance':
    [re.compile('消費者金融')],

    'Post office':
    [re.compile('郵便局|日本郵便')],
    },

    'fraud':{
    'Credit card info':
    [re.compile('(カード|クレカ)情報|(カード|クレカ)番号')],

    'Phone number':
    [re.compile('(電話|携帯)番号')],

    'Authentication info':
    [[re.compile('[a-zA-Z]+ID'), re.compile('ID[a-zA-Z]+')],    # 対象外
    re.compile('(認証|アカウント|ログイン)情報|ID|パスワード|暗証番号')], 

    'Account info':
    [re.compile('口座(情報|番号)')],

    'Address':
    [re.compile('住所')],
    }
}