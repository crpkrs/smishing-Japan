import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from h2_sms_patern import word_paterns

# 実行期間
period = (2015, 2021)

path = "output/SMSword/"
df = pd.read_excel('h1_sms_twitter.xlsx')

word_cnt = {}
years = np.arange(period[0], period[1] + 1)
for word_patern in word_paterns:
    word_cnt[word_patern] = [0] * len(years)

idx = np.arange(0, len(df['date']) - 1)
for i in idx:
    for year in years:
        if df.loc[i, 'year'] == year:
            word1 = str(df.loc[i, 'Types of Spam messages'])
            word2 = str(df.loc[i, 'Types of Spam messages2'])
            word3 = str(df.loc[i, 'Types of Spam messages3'])
            word4 = str(df.loc[i, 'Types of Spam messages4'])
            word5 = str(df.loc[i, 'Types of Spam messages5'])
            word6 = str(df.loc[i, 'Types of Spam messages6'])
            word7 = str(df.loc[i, 'Types of Spam messages7'])
            word8 = str(df.loc[i, 'Types of Spam messages8'])
            word9 = str(df.loc[i, 'Types of Spam messages9'])
            word10 = str(df.loc[i, 'Types of Spam messages10'])
            if word1 != 'nan':
                word_cnt[word1][year - period[0]] += 1
                if word2 != 'nan':
                    word_cnt[word2][year - period[0]] += 1
                    if word3 != 'nan':
                        word_cnt[word3][year - period[0]] += 1
                        if word4 != 'nan':
                            word_cnt[word4][year - period[0]] += 1
                            if word5 != 'nan':
                                word_cnt[word5][year - period[0]] += 1
                                if word6 != 'nan':
                                    word_cnt[word6][year - period[0]] += 1
                                    if word7 != 'nan':
                                        word_cnt[word7][year - period[0]] += 1
                                        if word8 != 'nan':
                                            word_cnt[word8][year - period[0]] += 1
                                            if word9 != 'nan':
                                                word_cnt[word9][year - period[0]] += 1
                                                if word10 != 'nan':
                                                    word_cnt[word10][year - period[0]] += 1

# その他の処理
other_words = []
word_cnt['All others'] = [0] * len(years)
for word_key, word_value in word_cnt.items():
    if sum(word_value) < 5:
        other_words.append(word_key)
        word_cnt['All others'] = np.array(word_cnt['All others']) + np.array(word_cnt[word_key])
for other_word in other_words:
    word_cnt.pop(other_word)

plot_df = pd.DataFrame({'year': years})
plot_df = plot_df.set_index('year')
n = 5
for word_key, word_value in word_cnt.items():
    plot_df[word_key] = word_value

os.makedirs(path, exist_ok=True)
plot_df.plot(kind='bar', stacked=True, figsize=(12, 8))
plt.xticks(rotation=0, fontsize=25)
plt.yticks(fontsize=25)
plt.legend(fontsize=25)
plt.xlabel(' ', fontsize=15)
plt.ylabel(' ', fontsize=15)
plt.tight_layout()
plt.savefig(path + 'SMSword.pdf')
plt.close()