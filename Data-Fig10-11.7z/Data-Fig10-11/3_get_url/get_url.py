import re, os
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

# ファイルパス
path1 = "../2_get_text/output/text_{}.{}.{}-{}.{}.csv"
path2 = "output/short_url_{}.{}.{}-{}.{}.txt"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

os.makedirs("output", exist_ok=True)

#　１ファイル処理
while True:
    ld = get_last_date(sd)

    #　入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)
    out_file_path = path2.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    #　入出力ファイルを開く
    read_file = open(get_file_path, 'r', encoding='utf-8')
    make_file = open(out_file_path, 'w', encoding='utf-8')
    
    #　１行処理
    while True:
        text = read_file.readline()
        if text:

            # 番号の抽出
            num = text[: text.find(',')]

            #　URLの抽出
            url_list = []
            url_list = re.findall('https?://t.co/[a-zA-Z0-9]{10}', text)
            
            # 書き込み
            if len(url_list) > 0:
                for url in url_list:
                    make_file.write(num + ' ' + url + '\n')

        # 読み込む行が存在しない為、入出力ファイルを閉じて終了
        else:
            read_file.close()
            make_file.close()
            break

    # 次のファイル名（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)