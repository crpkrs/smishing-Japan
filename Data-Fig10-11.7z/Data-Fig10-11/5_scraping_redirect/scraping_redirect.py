import os, re, csv, time, requests
from bs4 import BeautifulSoup
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

# ファイルパス
path1 = "../4_redirect_url/output/url_{}.{}.{}-{}.{}.txt"
path2 = "output/scraping_{}.{}.{}-{}.{}.txt"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

def check_url(url, url_list):
    if not url in url_list:
        url_list.append(url)
        try:
            time.sleep(10)
            site = requests.get(url, timeout=(6.0, 10.0))
            site.raise_for_status()                             # 200番台以外の場合、例外を起こす。
            return site
        except requests.exceptions.RequestException:
            return 'error'

def scraping(site):
    try:
        soup = BeautifulSoup(site.text, 'html.parser')
        title = soup.find('title').text
        if ('スミッシング' in title) or (('SMS' in title) and re.search('フィッシング|不正|詐欺|偽|名乗る|名乗った|騙る|騙った|かたる|かたった|なりすます|なりすました|装う|装った', title)):
            p = soup.find_all('p', id=None, class_=None, style=None)
            text_list_1 = []
            for txt in p:
                text_list_1.append(txt.text)
            text_list_2 = []
            for i in text_list_1:
                i = re.sub('\s', '', i)
                text_list_2.append(i)
            text_list = [j for j in text_list_2 if j != '']
            text_list = list(set(text_list))
            if len(text_list) > 0:
                return title, text_list
            else:
                return 'error'
        else:
            return 'error'
    except AttributeError:
        return 'error'

def check_text(text_list, text_dict):
    for text_value in text_dict.values():

        # 同じ<p>が3/4以上ある場合、同一サイトと判断
        penalty = 0
        for txt in text_list:
            if txt in text_value:
                penalty += 1
        if penalty >= len(text_list) * 3 / 4:
            return 'error'
    return 0

url_list = []
title_list = []
text_dict = {}
count_site = {}
site_all_count = 0
get_url_dict = {}
os.makedirs("output", exist_ok=True)

# １ファイル処理（ループ）
while True:
    count = 0
    ld = get_last_date(sd)
    print(str(sd.year) + '/' + str(sd.month))
    get_url_dict[str(sd.year) + '/' + str(sd.month)] = []

    # 入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)
    out_file_path = path2.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    if os.path.exists(get_file_path):
        
        # 入出力ファイルを開く
        read_file = open(get_file_path, 'r', encoding='utf-8')
        make_file = open(out_file_path, 'w', encoding='utf-8')

        # １行処理（ループ）
        while True:
            line = read_file.readline()
            if line:
                error = 0

                # 番号とURLの抽出
                idx = line.find(' ')
                num = line[: idx]
                url = line[idx + 1 : -1]

                # 同じURLに対しては、スクレイピングを行わない
                site = check_url(url, url_list)

                if type(site) is requests.models.Response:

                    # タイトルと本文の抽出
                    scraping_return = scraping(site)
                    if type(scraping_return) is tuple:
                        title = scraping_return[0]
                        text_list = scraping_return[1]

                        # 全く同じタイトルに対しては、出力を行わない
                        if title not in title_list:
                            title_list.append(title)

                            # 同じ本文に対しては、出力を行わない
                            if check_text(text_list, text_dict) == 0:
                                count += 1
                                text_dict[url] = text_list
                                get_url_dict[str(sd.year) + '/' + str(sd.month)].append(url)

                                # URLの書き込み
                                make_file.write('====================================================\n')
                                make_file.write(num + ' ' + url + '\n\n')

                                # タイトルの書き込み
                                make_file.write('----------------------------------------------------\n')
                                make_file.write(title + '\n\n')

                                # 本文の書き込み
                                make_file.write('----------------------------------------------------\n')
                                for txt in text_list:
                                    make_file.write(txt + '\n')
                                make_file.write('\n')

            # 読み込む行が存在しない為、入出力ファイルを閉じて終了
            else:         
                read_file.close()
                make_file.close()
                break
       
    count_site[str(sd.year) + '/' + str(sd.month)] = count
    site_all_count += count

    # 次のファイル名（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)

# 取得したサイト数を出力
with open('output/count_site.csv', 'w', encoding='utf-8') as count_file:
    w = csv.writer(count_file, lineterminator='\n')
    w.writerow(['総数 : ' + str(sum(count_site.values())) + 'サイト'])
    w.writerow([])
    for date_, count in count_site.items():
        w.writerow([date_, str(count)])

# 取得したサイトのURLを出力
with open('output/all_url.txt', 'w', encoding='utf-8') as f:
    for date_, url_list in get_url_dict.items():
        f.write(str(date_) + '\n')
        for url in url_list:
            f.write(url + '\n')
        f.write('\n')