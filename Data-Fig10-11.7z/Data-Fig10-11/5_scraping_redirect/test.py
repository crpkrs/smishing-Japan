import os, re, csv, time, requests
from bs4 import BeautifulSoup


site = requests.get('https://www.value-press.com/pressrelease/138499', timeout=(6.0, 10.0))
site.raise_for_status()
soup = BeautifulSoup(site.text, 'html.parser')
title = soup.find('title').text
if ('スミッシング' in title) or (('SMS' in title) and re.search('フィッシング|不正|詐欺|偽|名乗る|名乗った|騙る|騙った|かたる|かたった|なりすます|なりすました|装う|装った', title)):
    p = soup.find_all('p', id=None, class_=None, style=None)
    text_list_1 = []
    for txt in p:
        text_list_1.append(txt.text)
    text_list_2 = []
    for i in text_list_1:
        i = re.sub('\s', '', i)
        text_list_2.append(i)
    text_list = [j for j in text_list_2 if j != '']
    text_list = list(set(text_list))
    print(text_list)
