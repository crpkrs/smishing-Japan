import os
from janome.analyzer import Analyzer
from janome.charfilter import UnicodeNormalizeCharFilter, RegexReplaceCharFilter
from janome.tokenfilter import CompoundNounFilter, POSKeepFilter, ExtractAttributeFilter
from datetime import date
from dateutil.relativedelta import relativedelta
from calendar import monthrange

# ファイルパス
path1 = "../5_scraping_redirect/output/scraping_{}.{}.{}-{}.{}.txt"
path2 = "output/word_{}.{}.{}-{}.{}.txt"

# 実行期間
start_date = date(2015, 1, 1)
end_date = date(2021, 12, 31)
sd = start_date

# 月の最終日
def get_last_date(dt):
    return dt.replace(day=monthrange(dt.year, dt.month)[1])

char_filters = [
    UnicodeNormalizeCharFilter(),
    RegexReplaceCharFilter('https?://[\w/:%#\$&\?\(\)~\.=\+\-…]+', ' '),
    RegexReplaceCharFilter('[!?:;<>{}・`.,()-=$/_\'"\[\]\|]+', ' ')
]

token_filters = [
    CompoundNounFilter(),
    POSKeepFilter([
    '名詞,固有名詞',
    '名詞,複合'
    ]),
    ExtractAttributeFilter('surface')
]

a = Analyzer(char_filters = char_filters, token_filters = token_filters)
title = 0
os.makedirs('output', exist_ok=True)

# １ファイル処理（ループ）
while True:
    ld = get_last_date(sd)

    # 入出力ファイルパスの取得
    get_file_path = path1.format(sd.year, sd.month, sd.day, ld.month, ld.day)
    out_file_path = path2.format(sd.year, sd.month, sd.day, ld.month, ld.day)

    if os.path.exists(get_file_path):

        # 入出力ファイルを開く
        read_file = open(get_file_path, 'r', encoding='utf-8')
        make_file = open(out_file_path, 'w', encoding='utf-8')

        # 本文の単語の抽出
        while True:
            line = read_file.readline()
            if line:
                if line == '='*52 + '\n':
                    word_list = []
                    while line != '-'*52 + '\n':
                        line = read_file.readline()
                    line = read_file.readline()
                    while line != '-'*52 + '\n':
                        line = read_file.readline()
                    while line != '\n':
                        line = read_file.readline()
                        for token in a.analyze(line):
                            word_list.append(token)
                    
                    # 抽出した単語を出力する
                    for word in set(word_list):
                        make_file.write(str(word) + '\n')
            else:
                read_file.close()
                make_file.close()
                break
    
    # 次のファイル名（日付更新）
    if (sd.year == end_date.year) and (sd.month == end_date.month):
        break
    else:
        sd += relativedelta(months=1)